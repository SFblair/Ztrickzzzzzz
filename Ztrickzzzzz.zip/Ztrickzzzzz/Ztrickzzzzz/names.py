import os

print("Ztrickzzzzz by SFblair./n(c) 2020 name sniper mc all rights reserved")

while True:
    cmd = input("os_windows>")

if cmd =="":
    print("\n")

else:

    os.system.(cmd)