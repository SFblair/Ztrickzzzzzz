def menu():
    print("[1] run name")
    print("[2] name vault")
    print("[0] exit the program.")


menu()
option = int(input("enter your option")

while option != 0:
    if option == 1
    #do run name stuff
    print("running Ztrickzzzzzz.")
elif  option == 2:
    #do name vault stuff
    print("working name vault.")
else:
    print("invalid run."

print("pls type name you want to snipe.")
    menu()
option = int(input("enter your option")

print("name snipe failed.    try later.")